<?php
// Static list of food items
$foods = [
    ["id" => 1, "name" => "Margherita Pizza", "description" => "Classic cheese and tomato pizza with fresh basil.", "price" => 8.99, "image_url" => "https://media.istockphoto.com/id/1269122740/photo/pizza-with-very-much-cheese-melting.webp?a=1&b=1&s=612x612&w=0&k=20&c=GRG9S05DDKE1OXUTc5V-dncsevWOYg0xtebge1GQhrM="],
    ["id" => 2, "name" => "Spaghetti Carbonara", "description" => "Creamy pasta with pancetta, egg, and Parmesan cheese.", "price" => 12.49, "image_url" => "https://images.unsplash.com/photo-1588013273468-315fd88ea34c?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8U3BhZ2hldHRpJTIwQ2FyYm9uYXJhfGVufDB8fDB8fHww"],
    ["id" => 3, "name" => "Caesar Salad", "description" => "Crisp romaine lettuce, croutons, and Caesar dressing.", "price" => 6.99, "image_url" => "https://via.placeholder.com/300x200?text=Caesar+Salad"],
    ["id" => 4, "name" => "Chicken Alfredo", "description" => "Grilled chicken with creamy Alfredo sauce and fettuccine pasta.", "price" => 14.99, "image_url" => "https://via.placeholder.com/300x200?text=Chicken+Alfredo"],
    ["id" => 5, "name" => "BBQ Burger", "description" => "Juicy beef burger with BBQ sauce, lettuce, and tomato.", "price" => 10.49, "image_url" => "https://via.placeholder.com/300x200?text=BBQ+Burger"],
    ["id" => 6, "name" => "Fish Tacos", "description" => "Fresh fish, shredded cabbage, and spicy mayo in a tortilla.", "price" => 9.99, "image_url" => "https://via.placeholder.com/300x200?text=Fish+Tacos"],
    ["id" => 7, "name" => "Steak Frites", "description" => "Grilled steak served with crispy French fries.", "price" => 19.99, "image_url" => "https://via.placeholder.com/300x200?text=Steak+Frites"],
    ["id" => 8, "name" => "Vegetable Stir Fry", "description" => "A mix of fresh vegetables stir-fried with soy sauce and garlic.", "price" => 11.49, "image_url" => "https://via.placeholder.com/300x200?text=Vegetable+Stir+Fry"],
    ["id" => 9, "name" => "Tiramisu", "description" => "Classic Italian dessert with mascarpone, espresso, and cocoa.", "price" => 7.99, "image_url" => "https://via.placeholder.com/300x200?text=Tiramisu"],
    ["id" => 10, "name" => "Sushi Platter", "description" => "An assortment of fresh sushi and sashimi.", "price" => 25.99, "image_url" => "https://via.placeholder.com/300x200?text=Sushi+Platter"],
    ["id" => 11, "name" => "Pad Thai", "description" => "Thai rice noodles stir-fried with shrimp, peanuts, and tamarind sauce.", "price" => 13.99, "image_url" => "https://via.placeholder.com/300x200?text=Pad+Thai"],
    ["id" => 12, "name" => "Ratatouille", "description" => "A French vegetable medley cooked with olive oil and herbs.", "price" => 12.99, "image_url" => "https://via.placeholder.com/300x200?text=Ratatouille"],
    ["id" => 13, "name" => "Greek Salad", "description" => "Tomatoes, cucumbers, olives, and feta cheese with olive oil.", "price" => 9.49, "image_url" => "https://via.placeholder.com/300x200?text=Greek+Salad"],
    ["id" => 14, "name" => "Butter Chicken", "description" => "Creamy and spicy Indian curry served with naan bread or rice.", "price" => 15.49, "image_url" => "https://via.placeholder.com/300x200?text=Butter+Chicken"],
    ["id" => 15, "name" => "Clam Chowder", "description" => "Rich and creamy soup with clams, potatoes, and bacon.", "price" => 8.99, "image_url" => "https://via.placeholder.com/300x200?text=Clam+Chowder"],
    ["id" => 16, "name" => "Beef Tacos", "description" => "Soft tacos filled with spiced ground beef and toppings.", "price" => 9.99, "image_url" => "https://via.placeholder.com/300x200?text=Beef+Tacos"],
    ["id" => 17, "name" => "Grilled Salmon", "description" => "Perfectly grilled salmon with lemon butter sauce.", "price" => 18.99, "image_url" => "https://via.placeholder.com/300x200?text=Grilled+Salmon"],
    ["id" => 18, "name" => "Margarita Cocktail", "description" => "Refreshing tequila-based cocktail with lime and salt.", "price" => 10.49, "image_url" => "https://via.placeholder.com/300x200?text=Margarita+Cocktail"],
    ["id" => 19, "name" => "Chocolate Lava Cake", "description" => "Rich chocolate cake with a gooey molten center.", "price" => 8.99, "image_url" => "https://via.placeholder.com/300x200?text=Chocolate+Lava+Cake"],
    ["id" => 20, "name" => "BBQ Ribs", "description" => "Tender ribs glazed with smoky BBQ sauce.", "price" => 21.99, "image_url" => "https://via.placeholder.com/300x200?text=BBQ+Ribs"]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - The Gourmet Haven</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: #333;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            padding: 20px 40px;
            background-color: #333;
            color: white;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
        }
        .navbar a:hover {
            text-decoration: underline;
        }
        .banner {
            text-align: center;
            padding: 50px 0;
            background-color: #4CAF50;
            color: white;
        }
        .banner h1 {
            font-size: 2.5em;
            margin: 0;
        }
        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            text-align: center;
            flex: 1 1 calc(33% - 20px);
            max-width: calc(33% - 20px);
        }
        .card img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
        .card h3 {
            margin: 15px 0;
            font-size: 1.5em;
        }
        .card p {
            padding: 0 15px;
            font-size: 1em;
            color: #555;
        }
        .card .price {
            font-size: 1.2em;
            color: #4CAF50;
            font-weight: bold;
            margin: 10px 0;
        }
        .card button {
            background: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-bottom: 20px;
        }
        .card button:hover {
            background: #45a049;
        }
        @media (max-width: 768px) {
            .card {
                flex: 1 1 calc(50% - 20px);
                max-width: calc(50% - 20px);
            }
        }
        @media (max-width: 480px) {
            .card {
                flex: 1 1 100%;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="navbar">
        <div>Gourmet Haven</div>
        <div>
        <a href="Home_page.php">Home</a>
            <a href="About us.php">About</a>
            <a href="Menu.php">Menu</a>
            <a href="Reviews.php">Reviews</a>
            <a href="Contact us.php">Contact</a>
        </div>
    </div>
    <div class="banner">
        <h1>Welcome to Gourmet Haven</h1>
        <p>Delicious meals crafted with love</p>
    </div>
    <div class="container">
        <?php foreach ($foods as $food): ?>
            <div class="card">
                <img src="<?= $food['image_url'] ?>" alt="<?= $food['name'] ?>">
                <h3><?= $food['name'] ?></h3>
                <p><?= $food['description'] ?></p>
                <p class="price">$<?= number_format($food['price'], 2) ?></p>
                <button>Order Now</button>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
