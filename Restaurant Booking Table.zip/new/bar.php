<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Happiness Cards</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #fffaf5;
            margin: 0;
            padding: 20px;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: #ffe6d8;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        .top-bar button {
            background-color: #ff671c;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .top-bar button:hover {
            background-color: #e65a12;
            transform: scale(1.05);
        }
        .card-section {
            text-align: center;
        }
        .card-section h2 {
            margin-bottom: 20px;
        }
        .card-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
        }
        .card {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 300px;
            padding: 15px;
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-10px);
        }
        .card img {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 15px;
        }
        .card .price {
            color: #333;
            font-size: 24px;
            margin-bottom: 10px;
        }
        .card button {
            background-color: #ff671c;
            border: none;
            color: white;
            padding: 10px 15px;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .card button:hover {
            background-color: #e65a12;
        }
        .view-all {
            text-align: right;
            margin-bottom: 20px;
        }
        .view-all a {
            text-decoration: none;
            color: #333;
            font-size: 16px;
            padding: 5px 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            transition: background-color 0.3s, color 0.3s;
        }
        .view-all a:hover {
            background-color: #ddd;
            color: #000;
        }
    </style>
</head>
<body>

    <div class="top-bar">
        <div>
            <label>Select Restaurant</label>
            <strong>Select Restaurant</strong>
        </div>
        <button>Reserve Table</button>
    </div>

    <div class="card-section">
        <h2>Happiness Cards</h2>
        <div class="view-all">
            <a href="#">View All</a>
        </div>
        <div class="card-container">
            <div class="card">
                <img src="happiness_card_1000.jpg" alt="Happiness Card ₹1000"> <!-- Replace with actual image path -->
                <p>Happiness Gift Card <a href="#">View Detail</a></p>
                <p class="price">₹1000</p>
                <button>Add</button>
            </div>
            <div class="card">
                <img src="happiness_card_2500.jpg" alt="Happiness Card ₹2500"> <!-- Replace with actual image path -->
                <p>Happiness Gift Card <a href="#">View Detail</a></p>
                <p class="price">₹2500</p>
                <button>Add</button>
            </div>
        </div>
    </div>

</body>
</html>
