<?php
// This could be used to dynamically set the restaurant's name, description, and images
$restaurantName = "The Green Haven";
$description = "Welcome to The Gourmet Haven, where we serve culinary delights made with the freshest ingredients. Our mission is to provide a warm and inviting dining experience with dishes inspired by global flavors. Come and indulge in a journey of taste and comfort.";
$chefName = "Chef John Smith";
$history = "Established in 2010, The Gourmet Haven has been a cornerstone of the local community, known for its exceptional food and service. Our journey started as a small family-owned bistro and has grown into a renowned spot for fine dining.";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - <?php echo $restaurantName; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }

        /* Navbar styles */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 100px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 99;
            background: transparent;
            transition: background-color 0.3s, box-shadow 0.3s;
            background-color: rgba(52, 58, 64, 0.9);
        }

        .header.scrolled {
            background-color: rgba(52, 58, 64, 0.9); /* Dark background with some transparency */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header .logo {
            font-size: 1.7em;
            color: white;
            text-decoration: none;
        }

        .nav a {
            position: relative;
            font-size: 1.1em;
            color: white;
            text-decoration: none;
            margin-left: 40px;
        }

        .nav a::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -6px;
            width: 100%;
            height: 3px;
            background: white;
            border-radius: 5px;
            transform: scaleX(0);
            transition: .4s;
        }

        .nav a:hover::after {
            transform: scaleX(1);
        }

        .container {
            width: 80%;
            margin: 100px auto 0; /* Adjusted margin to account for fixed navbar */
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1, h2 {
            color: #333;
        }

        p {
            color: #555;
            line-height: 1.6;
        }

        .image-section img {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .chef-section {
            margin-top: 20px;
        }

        footer {
            background-color: #343a40;
            color: white;
            padding: 1rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <header class="header" id="header">
        <a href="#" class="logo">
            <ion-icon name="restaurant"></ion-icon> Dining
        </a>
        <nav class="nav">
            <a href="Home_page.php">Home</a>
            <a href="About us.php">About</a>
            <a href="#">Menu</a>
            <a href="Reviews.php">Reviews</a>
            <a href="Contact.php">Contact</a>
        </nav>
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    </header>

    <script>
        // Add scroll effect to change navbar style
        window.addEventListener('scroll', function () {
            const header = document.getElementById('header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    </script>

    <!-- About Us Content -->
    <div class="container">
        <h1>About Us</h1>
        <p><?php echo $description; ?></p>
        
        <div class="image-section">
            <img src="pics/dining.jpg" alt="Restaurant Interior">
        </div>

        <h2>Our History</h2>
        <p><?php echo $history; ?></p>

        <div class="chef-section">
            <h2>Meet Our Head Chef</h2>
            <p>We are proud to have <?php echo $chefName; ?> leading our kitchen. With years of experience and a passion for exquisite flavors, <?php echo $chefName; ?> brings a unique touch to every dish served.</p>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; <?php echo date("Y"); ?> The Green Haven. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
