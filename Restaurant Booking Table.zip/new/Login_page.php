<?php
session_start();
$host = 'localhost';
$user = 'root'; // Default XAMPP user
$pass = ''; // Default XAMPP password is blank
$dbname = 'dining';

// Connect to the database
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Registration logic
if (isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO users (name, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sss', $name, $email, $password);

    if ($stmt->execute()) {
        // echo "Registration successful. You can now log in.";
    } else {
        // echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Login logic
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user;
            header("Location: Home_page.php");
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with that email.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dining Table</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <header class="header">
            <a href="#" class="logo">
                <ion-icon name="restaurant"></ion-icon> Dinning </a>
            <nav class="nav">
                <a href="Home_page.php">Home</a>
                <a href="About us.php">About</a>
                <a href="#">Menu</a>
                <a href="Reviews.php">Reviews</a>
                <a href="Contact us.php">Contact</a>

                <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
                <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
            </nav>
        </header>

        <section class="home">
            <div class="content">
                <h2> Dinning to honestly restaurant</h2>
                <p>A dining room is a room for consuming food. </p>
                <a href="#"> Get Started </a>
            </div>
            <div class="wapper-login" id="signinForm">
                <h2> Member Login </h2>
                <form method="POST" action="">
                    <div class="input-box">
                        <span class="icon"><ion-icon name="mail-unread"></ion-icon></span>
                        <input type="email" name="email" required>
                        <label for=""> Enter your email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                        <input type="password" name="password" required>
                        <label for=""> Enter your password</label>
                    </div>
                    <div class="remember-forgot">
                        <label for=""><input type="checkbox">Remember me</label>
                        <a href="#"> Forgot password ?</a>
                    </div>
                    <button type="submit" name="login" class="btn">Login</button>
                    <div class="register-link">
                        <p> Not a member? <a href="#" onclick="showSignup()">Sign Up now</a></p>
                    </div>
                </form>
            </div>
        
            <div class="wapper-login" id="signupForm" style="display: none;">
                <h2> Member Sign Up </h2>
                <form method="POST" action="">
                    <div class="input-box">
                        <span class="icon"><ion-icon name="person"></ion-icon></span>
                        <input type="text" name="name" required>
                        <label for=""> Enter your name</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><ion-icon name="mail-unread"></ion-icon></span>
                        <input type="email" name="email" required>
                        <label for=""> Enter your email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                        <input type="password" name="password" required>
                        <label for=""> Enter your password</label>
                    </div>
                    <button type="submit" name="register" class="btn">Sign Up</button>
                    <div class="register-link">
                        <p> Already a member? <a href="#" onclick="showSignin()">Sign In now</a></p>
                    </div>
                </form>
            </div>
        </section>
        
        <script>
            let isCustomerSelected = true;
    
            function toggleUserType() {
                isCustomerSelected = !isCustomerSelected;
                document.getElementById("toggleSlider").style.left = isCustomerSelected ? "5px" : "calc(50% + 5px)";
                document.getElementById("customerOption").classList.toggle("selected", isCustomerSelected);
                document.getElementById("restaurantOption").classList.toggle("selected", !isCustomerSelected);
            }
            function showSignup() {
                document.getElementById('signinForm').style.display = 'none';
                document.getElementById('signupForm').style.display = 'block';
            }

            function showSignin() {
                document.getElementById('signinForm').style.display = 'block';
                document.getElementById('signupForm').style.display = 'none';
            }

        </script>
    </body>
</html>
