<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Gourmet Delight</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Custom CSS */
        body {
            font-family: Arial, sans-serif;
        }

        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 100px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 99;
            background: transparent;
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .header.scrolled {
            background-color: rgba(52, 58, 64, 0.9); /* Dark background with some transparency */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header .logo {
            font-size: 1.7em;
            color: white;
            text-decoration: none;
        }

        .nav a {
            position: relative;
            font-size: 1.1em;
            color: white;
            text-decoration: none;
            margin-left: 40px;
        }

        .nav a::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -6px;
            width: 100%;
            height: 3px;
            background: white;
            border-radius: 5px;
            transform: scaleX(0);
            transition: .4s;
        }

        .nav a:hover::after {
            transform: scaleX(1);
        }

        .hero-section {
            position: relative;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            text-align: center;
            overflow: hidden;
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('https://plus.unsplash.com/premium_photo-1661953124283-76d0a8436b87?q=80&w=1188&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D') no-repeat center center/cover;
            filter: blur(3px); /* Adjust blur value as needed */
            z-index: -1;
        }

        .hero-section .content {
            position: relative;
            z-index: 1;
        }

        .hero-section h1, .hero-section p {
            animation: fadeIn 2s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .card:hover {
            transform: translateY(-10px);
            transition: transform 0.3s;
        }

        footer {
            background-color: #343a40;
            color: white;
            padding: 1rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <header class="header" id="header">
        <a href="#" class="logo">
            <ion-icon name="restaurant"></ion-icon> Dining
        </a>
        <nav class="nav">
            <a href="Home_page.php">Home</a>
            <a href="About us.php">About</a>
            <a href="Menu.php">Menu</a>
            <a href="Reviews.php">Reviews</a>
            <a href="Contact us.php">Contact</a>
        </nav>
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    </header>

    <!-- Hero Section -->
    <header class="hero-section">
        <div class="content">
            <h1 class="display-4">Welcome to Gourmet Delight</h1>
            <p class="lead">Experience the best dining in town</p>
            <a href="#booking" class="btn btn-primary mt-3">Book a Table</a>
        </div>
    </header>

    <!-- JavaScript for scroll effect -->
    <script>
        window.addEventListener('scroll', function () {
            const header = document.getElementById('header');
            if (window.scrollY > 50) {
                header.classList.add('scrolled');
            } else {
                header.classList.remove('scrolled');
            }
        });
    </script>

    <!-- About Section -->
    <!-- <section id="about" class="container py-5">
        <h2 class="text-center mb-4">About Us</h2>
        <p class="text-center">At Gourmet Delight, we believe that dining is more than just eating—it’s an experience. Our chefs are dedicated to preparing the finest meals with the freshest ingredients, providing you with an unforgettable culinary journey.</p>
    </section> -->

    <!-- Menu Section -->
    <section id="menu" class="container py-5">
        <h2 class="text-center mb-4">Our Menu</h2>
        <div class="row">
            <?php
            $menu = [
                ['name' => 'Paneer chilli', 'description' => 'Served with a lemon butter sauce', 'price' => '₹ 320', 'image' => 'https://via.placeholder.com/300?text=Grilled+Salmon'],
                ['name' => 'Classic Burger', 'description' => 'Angus beef patty with fresh lettuce and house sauce', 'price' => '$15', 'image' => 'https://via.placeholder.com/300?text=Classic+Burger'],
                ['name' => 'Caesar Salad', 'description' => 'Romaine lettuce, parmesan cheese, and croutons', 'price' => '$12', 'image' => 'https://via.placeholder.com/300?text=Caesar+Salad'],
                ['name' => 'Pasta Primavera', 'description' => 'Fresh vegetables tossed with pasta in a light garlic sauce', 'price' => '$18', 'image' => 'https://via.placeholder.com/300?text=Pasta+Primavera'],
                ['name' => 'Margherita Pizza', 'description' => 'Classic pizza with mozzarella, tomatoes, and fresh basil', 'price' => '$20', 'image' => 'https://via.placeholder.com/300?text=Margherita+Pizza'],
                ['name' => 'Tiramisu', 'description' => 'Traditional Italian coffee-flavored dessert', 'price' => '$10', 'image' => 'https://via.placeholder.com/300?text=Tiramisu'],
                ['name' => 'Steak Frites', 'description' => 'Grilled steak with crispy fries and herb butter', 'price' => '$30', 'image' => 'https://via.placeholder.com/300?text=Steak+Frites'],
                ['name' => 'Lobster Bisque', 'description' => 'Rich and creamy lobster soup', 'price' => '$22', 'image' => 'https://via.placeholder.com/300?text=Lobster+Bisque'],
                ['name' => 'Chocolate Lava Cake', 'description' => 'Warm chocolate cake with a molten center', 'price' => '$12', 'image' => 'https://via.placeholder.com/300?text=Chocolate+Lava+Cake']
            ];
            foreach ($menu as $item) {
                echo "<div class='col-md-4 mb-4'>
                        <div class='card'>
                            <img src='{$item['image']}' class='card-img-top' alt='{$item['name']}'>
                            <div class='card-body'>
                                <h5 class='card-title'>{$item['name']}</h5>
                                <p class='card-text'>{$item['description']}</p>
                                <p class='card-text text-primary'>{$item['price']}</p>
                            </div>
                        </div>
                      </div>";
            }
            ?>
        </div>
    </section>

    <!-- Booking Section -->
    <section id="booking" class="bg-light py-5">
        <div class="container">
            <h2 class="text-center mb-4">Book a Table</h2>
            <form action="book_table.php" method="POST" class="p-4 border rounded shadow">
                <div class="mb-3">
                    <label for="name" class="form-label">Full Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="mb-3">
                    <label for="date" class="form-label">Date</label>
                    <input type="date" class="form-control" id="date" name="date" required>
                </div>
                <div class="mb-3">
                    <label for="time" class="form-label">Time</label>
                    <input type="time" class="form-control" id="time" name="time" required>
                </div>
                <button type="submit" class="btn btn-primary">Reserve Now</button>
            </form>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="container py-5">
        <h2 class="text-center mb-4">Contact Us</h2>
        <p class="text-center">For reservations or inquiries, reach us at:</p>
        <p class="text-center"><strong>Email:</strong> contact@gourmetdelight.com | <strong>Phone:</strong> (123) 456-7890</p>
    </section>

    <!-- Footer -->
    <footer class="mt-5">
        <p>&copy; <?php echo date("Y"); ?> Gourmet Delight. All rights reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
