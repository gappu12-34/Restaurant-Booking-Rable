<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barbeque Nation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fdf1e8;
        }
        .header {
            background-color: #fdf1e8;
            padding: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header img {
            height: 50px;
        }
        .nav {
            display: flex;
            gap: 20px;
        }
        .nav a {
            text-decoration: none;
            color: #000;
            font-size: 18px;
        }
        .main-banner {
            background-color: #ff671c;
            color: white;
            padding: 60px;
            text-align: center;
            font-size: 36px;
            font-weight: bold;
            background-image: url('food-background.jpg'); /* Placeholder for background images */
            background-size: cover;
            background-position: center;
        }
        .menu-items img {
            width: 100px;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="logo.png" alt="Barbeque Nation Logo"> <!-- Replace with actual logo path -->
        <div class="nav">
            <a href="#">Happiness Card</a>
            <a href="#">What's on BBQ</a>
            <a href="#">Restaurants</a>
            <a href="#">Catering</a>
        </div>
        <div>
            <button>Login</button>
            <button>Select Restaurant</button>
        </div>
    </div>

    <div class="main-banner">
        <p>Welcome to Barbeque Nation</p>
        <p>your Unlimited Celebration Destination!</p>
        <div class="food-images">
            <img src="skewers1.jpg" alt="Skewers"> <!-- Replace with actual image paths -->
            <img src="skewers2.jpg" alt="Skewers">
            <img src="shrimp.jpg" alt="Shrimp">
        </div>
        <p>Let us serve you better</p>
    </div>
</body>
</html>
