<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "dining";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize an array to store reviews
$reviews = [];

// Process the form data if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $rating = htmlspecialchars($_POST['rating']);
    $review = htmlspecialchars($_POST['review']);

    // Basic validation (for demonstration purposes)
    if (!empty($name) && !empty($rating) && !empty($review)) {
        // Insert the review into the database
        $stmt = $conn->prepare("INSERT INTO reviews (name, rating, review) VALUES (?, ?, ?)");
        $stmt->bind_param("sis", $name, $rating, $review);

        if ($stmt->execute()) {
            echo "<script>alert('Review submitted successfully!');</script>";
        } else {
            echo "<script>alert('Error submitting review.');</script>";
        }

        $stmt->close();
    } else {
        echo "<script>alert('Please fill out all fields.');</script>";
    }
}

// Retrieve all reviews from the database
$result = $conn->query("SELECT * FROM reviews ORDER BY date DESC");
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $reviews[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reviews - The Gourmet Haven</title>
    <style>
        /* General box-sizing rule */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            background: linear-gradient(to right, #f9f9f9, #e0e0e0);
        }

        /* Navbar styles */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 99;
            background: rgba(0, 0, 0, 0.8);
            transition: background-color 0.3s, box-shadow 0.3s;
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .header .logo {
            font-size: 2em;
            font-weight: bold;
            color: #fff;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: color 0.3s ease;
        }

        .header .logo:hover {
            color: #4CAF50;
        }

        .nav {
            display: flex;
            align-items: center;
            justify-content: flex-end;
        }

        .nav a {
            color: white;
            text-decoration: none;
            margin-left: 30px;
            font-size: 1.1em;
            padding: 8px 12px;
            transition: color 0.3s, background-color 0.3s;
            border-radius: 5px;
        }

        .nav a:hover {
            background-color: #4CAF50;
            color: white;
            transform: translateY(-2px);
        }

        /* Banner */
        .banner {
            height: 300px;
            background: url('https://images.pexels.com/photos/3183182/pexels-photo-3183182.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260') no-repeat center center/cover;
            position: relative;
            background-attachment: fixed;
        }

        .banner h1 {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            color: white;
            font-size: 3em;
            text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.7);
        }

        /* Container */
        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 30px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
            color: #555;
        }

        input, textarea, select {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            width: 100%;
        }

        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        .review {
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            background: #f9f9f9;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .review h3 {
            margin: 0;
            color: #333;
            font-size: 1.5em;
        }

        .review p {
            margin: 10px 0;
            color: #555;
        }

        .review .date {
            font-size: 0.9em;
            color: #888;
        }

        /* Mobile responsiveness */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                padding: 15px 20px;
            }

            .nav a {
                margin-left: 0;
                margin-bottom: 10px;
                font-size: 1em;
            }

            .header .logo {
                margin-bottom: 15px;
                font-size: 1.8em;
            }

            .banner h1 {
                font-size: 2em;
            }

            .container {
                padding: 20px;
            }
        }

    </style>
</head>
<body>
    <!-- Navbar -->
    <header class="header">
        <a href="#" class="logo">The Gourmet Haven</a>
        <nav class="nav">
            <a href="Home_page.php">Home</a>
            <a href="About_us.php">About</a>
            <a href="Menu.php">Menu</a>
            <a href="Reviews.php">Reviews</a>
            <a href="Contact.php">Contact</a>
        </nav>
    </header>

    <!-- Banner -->
    <div class="banner">
        <h1>Customer Reviews</h1>
    </div>

    <!-- Main content -->
    <div class="container">
        <h1>Leave a Review</h1>
        <form action="" method="post">
            <label for="name">Your Name</label>
            <input type="text" id="name" name="name" placeholder="Your name" required>

            <label for="rating">Rating (1-5)</label>
            <select id="rating" name="rating" required>
                <option value="">Select Rating</option>
                <option value="5">5 - Excellent</option>
                <option value="4">4 - Very Good</option>
                <option value="3">3 - Good</option>
                <option value="2">2 - Fair</option>
                <option value="1">1 - Poor</option>
            </select>

            <label for="review">Review</label>
            <textarea id="review" name="review" rows="5" placeholder="Write your review here" required></textarea>

            <button type="submit">Submit Review</button>
        </form>

        <h1>Reviews</h1>
        <?php if (!empty($reviews)) : ?>
            <?php foreach ($reviews as $review) : ?>
                <div class="review">
                    <h3><?php echo $review['name']; ?> - Rating: <?php echo $review['rating']; ?>/5</h3>
                    <p><?php echo $review['review']; ?></p>
                    <p class="date">Reviewed on: <?php echo $review['date']; ?></p>
                </div>
            <?php endforeach; ?>
        <?php else : ?>
            <p>No reviews yet. Be the first to leave a review!</p>
        <?php endif; ?>
    </div>
</body>
</html>
