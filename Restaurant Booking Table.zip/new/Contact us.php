<?php
// Process the form data if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Basic validation (for demonstration purposes)
    if (!empty($name) && !empty($email) && !empty($message)) {
        // Here you could add code to send the form data via email or save it to a database
        echo "<script>alert('Thank you, $name. Your message has been sent!');</script>";
    } else {
        echo "<script>alert('Please fill out all fields.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - The Gourmet Haven</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
        }
        /* Navbar styles */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            padding: 20px 100px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            z-index: 99;
            background: transparent;
            transition: background-color 0.3s, box-shadow 0.3s;
            background-color: rgba(52, 58, 64, 0.9);
        }

        .header.scrolled {
            background-color: rgba(52, 58, 64, 0.9); /* Dark background with some transparency */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .header .logo {
            font-size: 1.7em;
            color: white;
            text-decoration: none;
        }

        .nav a {
            position: relative;
            font-size: 1.1em;
            color: white;
            text-decoration: none;
            margin-left: 40px;
        }

        .nav a::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: -6px;
            width: 100%;
            height: 3px;
            background: white;
            border-radius: 5px;
            transform: scaleX(0);
            transition: .4s;
        }

        .nav a:hover::after {
            transform: scaleX(1);
        }

        .container {
            width: 50%;
            margin: 50px auto;
            margin-top: 90px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-top: 10px;
            color: #555;
        }
        input, textarea {
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 100%;
        }
        button {
            margin-top: 15px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .contact-info {
            margin-top: 20px;
            text-align: center;
        }
        .contact-info p {
            margin: 5px 0;
        }
        .map-section {
            margin-top: 30px;
            text-align: center;
        }
        iframe {
            width: 100%;
            height: 400px;
            border: 0;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <header class="header" id="header">
        <a href="#" class="logo">
            <ion-icon name="restaurant"></ion-icon> Dining
        </a>
        <nav class="nav">
            <a href="Home_page.php">Home</a>
            <a href="About us.php">About</a>
            <a href="#">Menu</a>
            <a href="Reviews.php">Reviews</a>
            <a href="Contact.php">Contact</a>
        </nav>
        <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
    </header>
    <div class="container">
        <h1>Contact Us</h1>
        <form action="" method="post">
            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" placeholder="Your name" required>

            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" placeholder="Your email" required>

            <label for="message">Message</label>
            <textarea id="message" name="message" rows="5" placeholder="Write your message here" required></textarea>

            <button type="submit">Send Message</button>
        </form>
        
        <div class="contact-info">
            <h2>Our Contact Details</h2>
            <p>Phone: (123) 456-7890</p>
            <p>Email: contact@gourmethaven.com</p>
            <p>Address: 123 Gourmet Lane, Food City, Yummyland</p>
        </div>

        <div class="map-section">
            <h2>Find Us Here</h2>
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8354345090704!2d144.95373531550408!3d-37.81720997975161!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad642af0f11fd81%3A0xf57764b3bb4c3a0!2sFederation%20Square!5e0!3m2!1sen!2sau!4v1600332411910!5m2!1sen!2sau" 
                allowfullscreen="" 
                loading="lazy">
            </iframe>
        </div>
    </div>
</body>
</html>
